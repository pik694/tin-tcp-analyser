package com.test.tcp_ip;

import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Server_Thread extends Thread {

    public ServerSocket serverSocket;
    public TextView serverTextView;

    public Server_Thread(TextView serverTextView){
        this.serverTextView = serverTextView;
    }

    @Override
    public void run() {
        try {
            serverTextView.setText(serverTextView.getText().toString() + "\n" + "serwer 1 ");
            serverSocket = new ServerSocket(7555);
            Socket socket = serverSocket.accept();
            serverTextView.setText(serverTextView.getText().toString() + "\n" + "serwer 2 ");
            new Server_Sender(socket).start();
            new Server_Receiver(socket, serverTextView).start();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
