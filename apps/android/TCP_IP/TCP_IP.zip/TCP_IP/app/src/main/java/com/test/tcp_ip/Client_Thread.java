package com.test.tcp_ip;

import android.widget.TextView;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Client_Thread extends  Thread {

    public TextView clientTextView;

    public Client_Thread(TextView clientTextView){
        this.clientTextView = clientTextView;
    }

    @Override
    public void run() {
        try {
            clientTextView.setText(clientTextView.getText().toString() + "\n" + "client 1");
            Socket clientSocket = new Socket("localhost", 7555);
            clientTextView.setText(clientTextView.getText().toString() + "\n" + "client 2");
            new Client_Sender(clientSocket).start();
            new Client_Receiver(clientSocket, clientTextView).start();
        }catch(IOException e){
            e.printStackTrace();
        }
    }
}
