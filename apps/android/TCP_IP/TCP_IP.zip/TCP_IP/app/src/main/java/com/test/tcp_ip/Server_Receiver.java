package com.test.tcp_ip;

import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

public class Server_Receiver extends Thread{

    public Socket server_socket;
    public BufferedReader reader;
    public String message;
    public TextView serverTextView;

    public Server_Receiver(Socket server_socket, TextView serverTextView){
        this.server_socket = server_socket;
        this.serverTextView = serverTextView;
    }

    @Override
    public void run() {
        try {
            reader = new BufferedReader(new InputStreamReader(server_socket.getInputStream()));
            do{
                message = reader.readLine();
                serverTextView.setText(serverTextView.getText().toString() + "\n" + message);
            }while(!message.equals('Q'));
        }catch(IOException e){
            e.printStackTrace();
        }finally{
            try {
                server_socket.close();
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }
}
