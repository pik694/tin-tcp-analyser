package com.test.tcp_ip;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

   TextView serverTextView;
   TextView clientTextView;

   public final int connectionPort = 7800;
   public final String ipAddress = "localhost";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        serverTextView = (TextView)findViewById(R.id.serverTextView);
        clientTextView = (TextView)findViewById(R.id.clientTextView);
    }


    public void startServer(View v){
        new Server_Thread(serverTextView).start();
    }

    public void startClient(View v){
        new Client_Thread(clientTextView).start();
    }
}
